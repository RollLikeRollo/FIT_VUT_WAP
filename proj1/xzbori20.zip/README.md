## WAP project no. 1
## - 
## The iterateProperties library

## Jan Zboril
### <xzbori20@stud.fit.vutbr.cz>

version 1.0  

FIT VUT Brno  
submission date: 2023-03-05  

tested in node v18.7.0 